import styles from './styles.module.css';

const Logo = () => <h1>Audious</h1>;

export default Logo;
