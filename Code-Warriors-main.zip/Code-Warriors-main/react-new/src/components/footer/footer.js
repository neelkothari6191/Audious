import styles from './styles.module.css';

const Footer = () => <div className={styles.footerBar}></div>;
export default Footer;
