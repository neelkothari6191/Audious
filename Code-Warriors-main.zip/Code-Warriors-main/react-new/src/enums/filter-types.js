const FilterTypes = Object.freeze({
    ALL: 0,
    CREATIONS: 1,
    COLLECTIONS: 2,
});

export default FilterTypes;
