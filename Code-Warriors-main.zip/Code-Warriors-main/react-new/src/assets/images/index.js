import playlistDefault from './playlist-default.png';
import playlistCoverZero from './playlist_cover_0.png';
import playlistCoverOne from './playlist_cover_1.jpg';
import playlistCoverTwo from './playlist_cover_2.png';
import playlistCoverThree from './playlist_cover_3.png';
import playlistCoverFour from './playlist_cover_4.png';
import playlistCoverFive from './playlist_cover_5.png';
import playlistCoverSix from './playlist_cover_6.png';
import playlistCoverSeven from './playlist_cover_7.png';
import playlistCoverEight from './playlist_cover_8.png';
import playlistCoverNine from './playlist_cover_9.png';
import playlistCoverTen from './playlist_cover_10.png';
import playlistCoverEleven from './playlist_cover_11.png';

export {
    playlistDefault,
    playlistCoverZero,
    playlistCoverOne,
    playlistCoverTwo,
    playlistCoverThree,
    playlistCoverFour,
    playlistCoverFive,
    playlistCoverSix,
    playlistCoverSeven,
    playlistCoverEight,
    playlistCoverNine,
    playlistCoverTen,
    playlistCoverEleven,
};
