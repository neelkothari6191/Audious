import React from 'react';

function Secret() {
  return <h1> Secret ^_^</h1>;
}

export default Secret;
